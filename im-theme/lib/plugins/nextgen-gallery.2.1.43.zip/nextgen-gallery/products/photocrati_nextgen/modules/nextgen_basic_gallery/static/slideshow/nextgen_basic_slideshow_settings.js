jQuery(function($) {
    $('input[name="photocrati-nextgen_basic_slideshow[show_thumbnail_link]"]')
        .nextgen_radio_toggle_tr('1', $('#tr_photocrati-nextgen_basic_slideshow_thumbnail_link_text'));
});