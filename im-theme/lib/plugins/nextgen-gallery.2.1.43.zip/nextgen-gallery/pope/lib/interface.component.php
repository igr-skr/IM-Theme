<?php

if (!defined('POPE_VERSION')) { die('Use autoload.php'); }

/**
 * Provides a generic interface to be registered with an adapter to modify any
 * component (within a particular context, if desired)
 */
interface I_Component
{

}