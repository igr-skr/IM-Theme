=== rus to lat advanced ===
Contributors: dmf_tuva
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=2JMPQXGL4NS2N
Tags: filename, translit, link, title
Requires at least: 2.8.x
Tested up to: 4.0.1
Stable tag: 1.1
Based on: The Wordpress Rus filename translit plugin by fixed77. 


Russian filename and link (from title) translitter for Wordpress.

== Description ==

Russian filename and link (from title) translitter for Wordpress. Russian filename and link (maked from title) not correct save by Wordpress.

Для примера из заголовка "Приказ № 343 г.Кызыл/.!@#$%^&*()_+|`~ё" получается правильная ссылка на запись "prikaz-N-343-g-kyzyl-_jo"
имя файла "Фото Ивановой И.И..jpg" сохранится как "Foto Ivanovoi I.I.jpg" (обратите внимание на 2 точки перед jpg)
Подпись останется по-русски.

== Installation ==

To use plugin, you will need:

* 	an installed and configured copy of WordPress version 2.6.x, 2.5.x,
	2.3.x, 2.2.x, 2.1.x, 2.0.x, or 1.5.x. (Wordpress Signaturer will also work with
	the equivalent versions of WordPress MU.)

*	FTP or SFTP access to your web host

= New Installations =

1.	Download plugin archive in zip or gzipped tar format and
	extract the files on your computer. 

2.	Copy  plugin in the `wp-content/plugins`
	directory of your WordPress installation. Use an FTP or SFTP client to
	upload the contents of your archive to the new directory
	that you just created on your web host.

3.	Log in to the WordPress Dashboard and activate plugin.

== Screenshots ==

1. File sample
2. Link sample

== Changelog ==

= 1.1 =
* Added Ukrainian(Sergii Golubev) and Kazakh(donatory) letters.
* Special characters (!@#$%^&) converted to ""

= 1.0 =
* Plugin release. Operate all the basic functions.

== License ==

The Russian filename and link (from title) translitter for Wordpress plugin is copyright © 2013 with [GNU General Public License][] by dmf_tuva.

This program is free software; you can redistribute it and/or modify it under
the terms of the [GNU General Public License][] as published by the Free
Software Foundation; either version 2 of the License, or (at your option) any
later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License for more details.

  [GNU General Public License]: http://www.gnu.org/copyleft/gpl.html
  